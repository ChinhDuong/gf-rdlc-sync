﻿namespace Eco_Apothecary_SureMedPlusRdlc.Models
{
    public static class ReportViewNames
    {
        public const string ReportViewName = "8e89cba4-8028-474a-8fa6-12dc5aa32812";
    }
}