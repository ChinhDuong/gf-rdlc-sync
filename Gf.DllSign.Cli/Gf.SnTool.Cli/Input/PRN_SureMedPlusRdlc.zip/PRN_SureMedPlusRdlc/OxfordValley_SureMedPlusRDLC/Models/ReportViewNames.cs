﻿namespace OxfordValley_SureMedPlusRDLC.Models
{
    public static class ReportViewNames
    {
        public const string ReportViewName = "9b63cfe6-e85a-462c-8004-a75eb15ec9cc";
    }
}