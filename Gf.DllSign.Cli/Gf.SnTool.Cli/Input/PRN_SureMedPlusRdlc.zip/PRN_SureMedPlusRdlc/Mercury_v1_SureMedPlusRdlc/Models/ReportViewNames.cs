﻿namespace Mercury_v1_SureMedPlusRdlc.Models
{
    public static class ReportViewNames
    {
        public const string ReportViewName = "6b4ddde3-dd5a-44da-8f80-bb6064e0da29";
    }
}