﻿namespace Mercy_SureMedPlusRdlc.Models
{
    public static class ReportViewNames
    {
        public const string ReportViewName = "f8d6c6f4-4358-4a83-93ea-8a6939631183";
    }
}