﻿namespace BJRX_v4_SureMedPlusRdlc.Models
{
    public static class ReportViewNames
    {
        public const string ReportViewName = "fa24beac-5d05-46aa-8f84-eb07f998ad7c";
    }
}