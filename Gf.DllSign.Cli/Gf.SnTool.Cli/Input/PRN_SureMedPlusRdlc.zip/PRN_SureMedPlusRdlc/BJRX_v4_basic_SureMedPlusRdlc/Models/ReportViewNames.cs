﻿namespace BJRX_v4_basic_SureMedPlusRdlc.Models
{
    public static class ReportViewNames
    {
        public const string ReportViewName = "d40d1003-a461-482e-bebf-cc4ab5080b77";
    }
}