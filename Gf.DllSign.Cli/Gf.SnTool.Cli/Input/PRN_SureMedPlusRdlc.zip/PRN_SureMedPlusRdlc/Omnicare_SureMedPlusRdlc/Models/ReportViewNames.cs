﻿namespace Omnicare_SureMedPlusRdlc.Models
{
    public static class ReportViewNames
    {
        public const string ReportViewName = "d4076d15-2d3e-4d3f-90cd-feb88c27d145";
    }
}