﻿namespace Omnicare_SureMedPlusRdlc.Models
{
    public static class ReportViewNames
    {
        public const string ReportViewName = "771929b1-ecfb-4af0-a84f-584da3109516";
    }
}