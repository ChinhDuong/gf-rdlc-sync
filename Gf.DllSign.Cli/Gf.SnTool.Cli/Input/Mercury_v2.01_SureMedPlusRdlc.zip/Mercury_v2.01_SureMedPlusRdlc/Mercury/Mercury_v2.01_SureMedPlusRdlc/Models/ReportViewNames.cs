﻿namespace SureMedPlusRdlc.Models
{
    public static class ReportViewNames
    {
        public const string ReportViewName = "3893f74e-fb4a-4943-93bc-d525bac798ac";
    }
}