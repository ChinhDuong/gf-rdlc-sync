﻿namespace Eco_Apothecary_SureMedPlusRdlc.Models
{
    public static class ReportViewNames
    {
        public const string ReportViewName = "eba40b34-bce3-42a7-bb66-b0b6b565ec98";
    }
}