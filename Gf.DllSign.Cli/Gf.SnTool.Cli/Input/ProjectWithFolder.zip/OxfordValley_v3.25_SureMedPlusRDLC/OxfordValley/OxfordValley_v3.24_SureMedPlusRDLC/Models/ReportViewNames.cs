﻿namespace SureMedPlusRdlc.Models
{
    public static class ReportViewNames
    {
        public const string ReportViewName = "0234f07e-09e8-4a71-9a0f-9edf231f348b";
    }
}