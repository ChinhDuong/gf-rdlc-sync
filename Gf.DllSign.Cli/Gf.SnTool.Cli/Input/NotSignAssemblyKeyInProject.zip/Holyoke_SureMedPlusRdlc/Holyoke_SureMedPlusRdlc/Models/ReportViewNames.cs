﻿namespace Holyoke_SureMedPlusRdlc.Models
{
    public static class ReportViewNames
    {
        public const string ReportViewName = "b4a21f70-6bac-473b-b09e-9b4359371fb1";
    }
}